<?php

/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: Fields.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Zulu_Form_Edit_ClinicalFields extends Zulu_Form_Common_ClinicalFields_Abstract {

  public function init() {
    // Init form
    $this->setTitle('Clinical Information')->setAttrib('id', 'EditClinical');

    parent::init();
  }

  public function generate() {
    // Check if user has Medical Record
    $hasMedicalRecord = !empty($this->getItem()->zulu_id);
    
    parent::generate();
    
    // User's href
    $href = Engine_Api::_()->core()->getSubject('user')->getHref();
    
    if($hasMedicalRecord) {
      // TOP print button
      $noteName = 'print_button_top';
      $note = new Zulu_Form_Element_Note(
              $noteName, array(
          'value' => $this->getView()->htmlLink($href . '/print', 'Print Medical Record', array(
              'class' => 'buttonlink icon_zulu_print',
              'alt' => 'Print Medical Record',
              'target' => '_blank'
          )),
          'order' => 0,
      ));
      $this->addElement($note);
      $this->getElement($noteName)->removeDecorator('Label')->removeDecorator('HtmlTag');

      // BOTTOM print button
      $noteName = 'print_button_bottom';
      $note = new Zulu_Form_Element_Note(
              $noteName, array(
          'value' => $this->getView()->htmlLink($href . '/print', 'Print Medical Record', array(
              'class' => 'buttonlink icon_zulu_print',
              'alt' => 'Print Medical Record',
              'target' => '_blank',
          )),
          'order' => 10000,
      ));
      $this->addElement($note);
      $this->getElement($noteName)->removeDecorator('Label')->removeDecorator('HtmlTag');
    }

    $this->addElement('Button', 'save', array(
        'label' => 'Save',
        'type' => 'submit',
        'order' => 10001,
    ));
    $this->getElement('save')->removeDecorator('DivDivDivWrapper');
    
    if($hasMedicalRecord) {
      // Get tab id of Medical Record in view profile page
      $db = Engine_Db_Table::getDefaultAdapter();
      $tab_id = $db->select()
              ->from('engine4_core_content', 'content_id')
              ->where('`name` = ?', 'zulu.clinical-fields')
              ->query()
              ->fetchColumn();

      // View Medical Record button
      $noteName = 'view';
      $note = new Zulu_Form_Element_Note(
              $noteName, array(
          'value' => $this->getView()->htmlLink($href . '/tab/' . $tab_id, 'View Medical Record', array(
              'class' => 'link_button',
              'alt' => 'View Medical Record',
              'target' => '_blank',
          )),
          'order' => 10002,
      ));
      $this->addElement($note);
      $this->getElement($noteName)->removeDecorator('Label')->removeDecorator('HtmlTag');
    }

    $this->addDisplayGroup(array('save', 'view'), 'buttons', array(
        'order' => 10001
    ));
  }

}
