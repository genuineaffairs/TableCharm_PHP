<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FormGrid
 *
 * @author abakivn
 */
class Zulu_View_Helper_FieldGrid extends Zend_View_Helper_Abstract {

  public function fieldGrid($subject, $field = null, $field_value = null) {
    // Try to get field id
    if(is_array($field_value) && array_key_exists('data-field-id', $field_value)) {
      $field_id = $field_value['data-field-id'];
    } elseif($field_value instanceof Fields_Model_Value && isset($field_value->field_id)) {
      $field_id = $field_value->field_id;
    } else {
      throw new Engine_Application_Exception('Unable to get field id');
    }

    $db = Engine_Db_Table::getDefaultAdapter();
    $value = json_decode(htmlspecialchars_decode($field_value->value), true);
    
    $data = $db->select()
              ->from('engine4_zulu_fields_xhtml')
              ->where('field_id = ?', $field_id)
              ->query()->fetch();
    
    $decoded_data = json_decode($data['field_data'], true);
    $gridFieldContent = '';
    $colnum = count($decoded_data['th']);

    $gridFieldContent .= <<<EOF
        <table class="zulu-grid-table grid-edit-table">
          <tr class="grid-header">
EOF;
            foreach($decoded_data['th'] as $th) {
              $gridFieldContent .= <<<EOF
            <th class="normal-col">
              {$th}
            </th>
EOF;
            }
          $gridFieldContent .= <<<EOF
          </tr>
EOF;
          $row_count = 0;
          
          if(!empty($value['options_in_select'])) {
            unset($value['options_in_select']);
          }
          
          if(empty($value) 
                  || (count($value) > count($decoded_data['td']) && !$data['user_edit_row'] )
                  || count($value) < count($decoded_data['td'])) {
            $value = array();
          }
          
          if(!empty($value['options_in_select'])) {
            unset($value['options_in_select']);
          }
          
          $i = 0;
          foreach($value as $v) {
            if($i % $colnum === 0) {
              $row_count++;
              $gridFieldContent .= <<<EOF
          <tr>
EOF;
            }
            $gridFieldContent .= <<<EOF
            <td class="normal-col">{$v}</td>
EOF;
            if($i % $colnum === $colnum - 1) {
              $gridFieldContent .= <<<EOF
          </tr>
EOF;
            }
            $i++;
          }
          
          $gridFieldContent .= <<<EOF
        </table>
EOF;
    
    return $gridFieldContent;
  }

}
