-- --------------------------------------------------------

ALTER TABLE `engine4_documents` CHANGE `fulltext` `fulltext` LONGTEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci NULL DEFAULT NULL;

-- --------------------------------------------------------
