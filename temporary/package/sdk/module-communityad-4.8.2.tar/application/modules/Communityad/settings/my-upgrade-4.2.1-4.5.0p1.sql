	INSERT IGNORE INTO `engine4_communityad_modules` (`module_name`, `module_title`, `table_name`, `title_field`, `body_field`, `owner_field`, `is_delete`) VALUES
  ('sitebusiness', 'Business', 'sitebusiness_business', 'title', 'body', 'owner_id', 1),
  ('sitegroup', 'Groups', 'sitegroup_group', 'title', 'body', 'owner_id', 1);