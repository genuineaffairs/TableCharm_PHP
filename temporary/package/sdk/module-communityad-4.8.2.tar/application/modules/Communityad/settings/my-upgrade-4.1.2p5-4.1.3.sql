ALTER TABLE `engine4_communityad_userads` ADD `renewbyadmin_date` DATETIME DEFAULT NULL;
