ALTER TABLE `engine4_communityad_adtargets` ADD `networks` VARCHAR( 500 ) NULL;
