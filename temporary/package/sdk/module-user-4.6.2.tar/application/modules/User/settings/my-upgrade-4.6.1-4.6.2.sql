-- Support branded sites

-- ALTER TABLE engine4_users ADD COLUMN site_id int(11) NOT NULL DEFAULT 1;