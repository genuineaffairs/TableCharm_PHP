DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.comment.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.recent.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.like.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.view.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.rate.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.featured.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagevideo.homerecentvideos.widgets' LIMIT 1;
