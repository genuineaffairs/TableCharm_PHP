<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of FormGrid
 *
 * @author abakivn
 */
class Zulu_View_Helper_FormGrid extends Zend_View_Helper_FormElement {

  public function formGrid($name, $value = null, $attribs = null, $options = null) {
    // Try to get field id
    if(is_array($attribs) && array_key_exists('data-field-id', $attribs)) {
      $field_id = $attribs['data-field-id'];
    } elseif($attribs instanceof Fields_Model_Value && isset($attribs->field_id)) {
      $field_id = $attribs->field_id;
    } else {
      throw new Engine_Application_Exception('Unable to get field id');
    }

    $db = Engine_Db_Table::getDefaultAdapter();
    $value = json_decode($value, true);

    $data = $db->select()
              ->from('engine4_zulu_fields_xhtml')
              ->where('field_id = ?', $field_id)
              ->query()->fetch();
    
    $decoded_data = json_decode($data['field_data'], true);
    $gridFieldContent = '';
    $supported_input_type = array(
        'text' => 'Text Input',
        'plain_text' => 'Plain Text',
        'dropdown' => 'Dropdown',
    );
    $colnum = count($decoded_data['th']);
    $options_in_select = null;
    $select_count = 0;
    $htmlAttribs = $this->_htmlAttribs($attribs);

    $gridFieldContent .= <<<EOF
    <table {$htmlAttribs}>
          <tr class="grid-header">
            <th class="grid-unused"></th>
EOF;
            $i = 0;
            foreach($decoded_data['th'] as $th) {
              if($i == 0) {
                $display = 'display:none';
              } else {
                $display = '';
              }
              $gridFieldContent .= <<<EOF
            <th class="normal-col">
              {$th}
            </th>
EOF;
              $i++;
            }
          $gridFieldContent .= <<<EOF
          </tr>
EOF;
          $i = 0;
          $row_count = 0;
          
          if(!empty($value['options_in_select'])) {
            $options_in_select = $value['options_in_select'];
            unset($value['options_in_select']);
          }

          if(empty($value) 
                  || (count($value) > count($decoded_data['td']) && !$data['user_edit_row'] )
                  || count($value) < count($decoded_data['td'])) {
            $value = $decoded_data['td'];
            $options_in_select = null;
          }
          
          foreach($value as $v) {
            $col_no = $i % $colnum;
            if($i % $colnum === 0) {
              if($row_count === 0 || !$data['user_edit_row']) {
                $display = 'display:none';
              } else {
                $display = 'display:block';
              }
              $row_count++;
              $gridFieldContent .= <<<EOF
          <tr>
            <td class="grid-unused">
              <span class="text">{$row_count}</span>
              <a style="{$display}" class="remove_row" href="javascript:void(0);" onclick="void(0);" onmousedown="void(0);">
                Remove row
              </a>
            </td>
EOF;
            }
            $gridFieldContent .= <<<EOF
            <td class="normal-col">
EOF;
            if($decoded_data['cell_type'][$col_no] == 'text') {
              // Text Input type column
              
              if($decoded_data['td'][$i] == $v) {
                $text_val = '';
              } else {
                $text_val = $v;
              }
              
              $gridFieldContent .= <<<EOF
              <textarea placeholder="{$decoded_data['td'][$i]}" name="{$name}[]">{$text_val}</textarea>
EOF;
            } elseif($decoded_data['cell_type'][$col_no] == 'dropdown') {
              // Dropdown type column
              // 
              // Get field options
              $options_in_select[$select_count] = json_decode($options_in_select[$select_count], true);
              if(is_array($options_in_select[$select_count]) && $data['user_edit_row']) {
                // Get options from user submit values (hidden input)
                $opts = $options_in_select[$select_count];
              } else {
                // Get options from field structure
                $opts = explode("\n", $decoded_data['td'][$i]);
              }
              
              if(!empty($opts)) {
                $gridFieldContent .= <<<EOF
              <select name="{$name}[]">
EOF;
                foreach($opts as $opt) {
                  $opt = preg_replace('/[\p{C}]+/u', '', $opt);
                  $v = preg_replace('/[\p{C}]+/u', '', $v);

                  if(strlen($opt) > 0) {
                    if($opt == $v) {
                      $selected = 'selected="selected"';
                    } else {
                      $selected = '';
                    }
                    $gridFieldContent .= <<<EOF
                <option {$selected} value="{$opt}">{$opt}</option>
EOF;
                  }
                }
                $json_options_in_select = htmlspecialchars(json_encode($opts));
                $gridFieldContent .= <<<EOF
              </select>
              <input type="hidden" name="{$name}[options_in_select][]" value="{$json_options_in_select}" />
EOF;
                $select_count++;
              } else {
                $gridFieldContent .= <<<EOF
              <input class="text" type="text" name="{$name}[]" value="{$v}" />
EOF;
              }
            } else {
              // Plain Text type column
              if(!empty($v)) {
                $plain_text = $v;
              } else {
                $plain_text = $decoded_data['td'][$i];
              }
              
              $gridFieldContent .= <<<EOF
              {$plain_text}
              <input name="{$name}[]" type="hidden" value="{$plain_text}" />
EOF;
            }
            $gridFieldContent .= <<<EOF
            </td>
EOF;
            if($i % $colnum === $colnum - 1) {
              $gridFieldContent .= <<<EOF
          </tr>
EOF;
            }
            $i++;
          }
          
          // Undisplay add row button if not allowed
          if(!$data['user_edit_row']) {
            $display = 'display:none';
          } else {
            $display = 'display:block';
          }
          $gridFieldContent .= <<<EOF
        </table>
        <p class="grid-type-description" style="{$display}"><a class="add_row" href="javascript:void(0);" onclick="void(0);" onmousedown="void(0);">Add row</a></p>
EOF;
    
    return $gridFieldContent;
  }

}
