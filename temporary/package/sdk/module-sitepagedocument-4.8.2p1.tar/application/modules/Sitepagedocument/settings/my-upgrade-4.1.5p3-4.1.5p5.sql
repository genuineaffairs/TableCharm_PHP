INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('sitepagedocument_admin_new', 'sitepagedocument', '{item:$subject} created a new document:', 1, 1, 2, 1, 1, 0);
