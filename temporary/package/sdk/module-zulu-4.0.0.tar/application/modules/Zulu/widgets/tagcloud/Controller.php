<?php

/**
 * YouNet Company
 *
 * @category   Application_Extensions
 * @package    Ynvideo
 * @author     YouNet Company
 */
class Zulu_Widget_TagCloudController extends Engine_Content_Widget_Abstract {

    public function indexAction() {
        
    }

}