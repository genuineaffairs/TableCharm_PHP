<?php

/**
 * YouNet Company
 *
 * @category   Application_Extensions
 * @package    Ynvideo
 * @author     YouNet Company
 */
class Zulu_Widget_TutorialVideoController extends Engine_Content_Widget_Abstract {

    public function indexAction() {
        
    }

}