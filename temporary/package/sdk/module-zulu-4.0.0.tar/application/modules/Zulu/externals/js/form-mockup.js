(function($) {
  // TODO: improve user interface by javascript effects in future
})(jQuery);