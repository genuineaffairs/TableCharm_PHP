-- --------------------------------------------------------

--
-- Table structure for table `engine4_activity_actiontypes`
--

INSERT IGNORE INTO `engine4_activity_actiontypes` (`type`, `module`, `body`, `enabled`, `displayable`, `attachable`, `commentable`, `shareable`, `is_generated`) VALUES
('sitepagevideo_admin_new', 'sitepagevideo', '{item:$subject} posted a new video:', 1, 1, 2, 1, 1, 0);

-- --------------------------------------------------------
