<?php

return array(
    array(
    'title' => 'Grand Opening Down Clock',
    'description' => 'Displays time before opening.',
    'category' => 'Grand Opening',
    'type' => 'widget',
    'name' => 'grandopening.countdown-timer'
  ),
  array(
    'title' => 'Grand Opening Email Form',
    'description' => 'Displays form for collection emails.',
    'category' => 'Grand Opening',
    'type' => 'widget',
    'name' => 'grandopening.email-form'
  )
) ?>
