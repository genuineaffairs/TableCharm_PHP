<?php

/**
 * SocialEngine
 *
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 * @version    $Id: ProfileController.php 9747 2012-07-26 02:08:08Z john $
 * @author     John
 */

/**
 * @category   Application_Core
 * @package    User
 * @copyright  Copyright 2006-2010 Webligo Developments
 * @license    http://www.socialengine.com/license/
 */
class Zulu_ProfileController extends Core_Controller_Action_Standard {

  public function init() {
    // @todo this may not work with some of the content stuff in here, double-check
    $subject = null;
    if (!Engine_Api::_()->core()->hasSubject()) {
      $id = $this->_getParam('id');

      // use viewer ID if not specified
      //if( is_null($id) )
      //  $id = Engine_Api::_()->user()->getViewer()->getIdentity();

      if (null !== $id) {
        $subject = Engine_Api::_()->user()->getUser($id);
        if ($subject->getIdentity()) {
          Engine_Api::_()->core()->setSubject($subject);
        }
      }
    }

    $this->_helper->requireSubject('user');
    $this->_helper->requireAuth()->setNoForward()->setAuthParams(
            $subject, Engine_Api::_()->user()->getViewer(), 'view'
    );
  }

  public function indexAction() {
    $subject = Engine_Api::_()->core()->getSubject();
    $viewer = Engine_Api::_()->user()->getViewer();

    // check public settings
    $require_check = Engine_Api::_()->getApi('settings', 'core')->core_general_profile;
    if (!$require_check && !$this->_helper->requireUser()->isValid()) {
      return;
    }

    // Check enabled
    if (!$subject->enabled && !$viewer->isAdmin()) {
      return $this->_forward('requireauth', 'error', 'core');
    }

    // Check block
    if ($viewer->isBlockedBy($subject) && !$viewer->isAdmin()) {
      return $this->_forward('requireauth', 'error', 'core');
    }

    // Increment view count
    if (!$subject->isSelf($viewer)) {
      $subject->view_count++;
      $subject->save();
    }


    // Check to see if profile styles is allowed
    $style_perm = Engine_Api::_()->getDbtable('permissions', 'authorization')->getAllowed('user', $subject->level_id, 'style');
    if ($style_perm) {
      // Get styles
      $table = Engine_Api::_()->getDbtable('styles', 'core');
      $select = $table->select()
              ->where('type = ?', $subject->getType())
              ->where('id = ?', $subject->getIdentity())
              ->limit();

      $row = $table->fetchRow($select);
      if (null !== $row && !empty($row->style)) {
        $this->view->headStyle()->appendStyle($row->style);
      }
    }

    // Render
    $this->_helper->content
            ->setNoRender()
            ->setEnabled()
    ;
  }

  public function printAction() {

    if (Zend_Registry::isRegistered('Zend_View')) {
      $view = Zend_Registry::get('Zend_View');

      if ($view) {
        $file = 'print.css';
        $view->headLink()->appendStylesheet($view->layout()->staticBaseUrl . 'application/modules/Zulu/externals/css/' . $file, 'screen, print');
      }
    }

    $viewer = Engine_Api::_()->user()->getViewer();

    if (Engine_Api::_()->core()->hasSubject()) {
      $subject = Engine_Api::_()->core()->getSubject('user');
    } else {
      return $this->_helper->requireAuth()->forward();
    }

    $zulu = Engine_Api::_()->getDbTable('zulus', 'zulu')->getZuluByUserId($subject->user_id);

    if (!Engine_Api::_()->getDbTable('accessLevel', 'zulu')->isAllowed($zulu, $viewer, 'print')) {
      return $this->_helper->requireAuth()->forward();
    }

    $user = $subject;
    $userMetaData = Engine_Api::_()->fields()->getFieldsMeta('user');
    $zuluMetaData = Engine_Api::_()->fields()->getFieldsMeta('zulu');

    $structureTop = Engine_Api::_()->fields()->getFieldStructureTop($zulu);

    $preHeader = '';

    $childhoodDiseases = $immunisations = $allergies = $operations = $medications = $others = array();
    $diseasesCount = $immunisationsCount = $allergiesCount = $operationsCount = $medicationsCount = $othersCount = 0;

    $dateFormat = 'd/m/Y';

    foreach ($structureTop as $map) {
      /* @var $field Fields_Model_Meta */
      $field = $map->getChild();
      if ($field->isHeading()) {
        $preHeader = $field->label;
      }

      // Get field value
      $value = $field->getValue($zulu);

      if (is_array($value)) {
        $value = $value[0];
      }

      // Handle data for personal history
      if (!$field->isHeading() && $preHeader === 'PERSONAL HISTORY') {
        // If field has value
        if (!empty($value) && !empty($value->value)) {
          $options = $field->getOptions();
          $label = $options[0]->label;
          $currentlyAffected = false;
          $date = '';

          $childMaps = $field->getParentMaps();

          foreach ($childMaps as $childMap) {
            $childField = $childMap->getChild();
            $childValue = $childField->getValue($zulu);

            if (is_array($childValue)) {
              $childValue = $childValue[0];
            }

            if (!empty($childValue) && !empty($childValue->value)) {
              // Dangerous when data changes
              if (preg_match('/currently affected/', $childField->alias)) {
                $selectedOptionId = $childValue->value;

                if (strtolower($childField->getOption($selectedOptionId)->label) === 'yes') {
                  $currentlyAffected = true;
                }
              }

              // Dangerous when data changes
              if (preg_match('/first occur/', $childField->alias)) {
                $date = $childValue->value;
              }
            }
          }

          if ($label) {
            $childhoodDiseases[$diseasesCount]['label'] = $label;
            $childhoodDiseases[$diseasesCount]['currentlyAffected'] = $currentlyAffected;
            if ($date) {
              $date = date($dateFormat, strtotime($date));
            }
            $childhoodDiseases[$diseasesCount]['date'] = $date;
          }

          $diseasesCount++;
        }
      }

      // Handle data for immunisation
      if (!$field->isHeading() && $preHeader === 'IMMUNISATIONS') {
        $immunisationData = json_decode(html_entity_decode($value->value), true);

        foreach ($immunisationData as $immunisation) {
          // Dangerous when data changes
          if (strtolower($immunisation[1]) === 'yes') {
            $immunisations[$immunisationsCount]['label'] = $immunisation['Type'];
            $immunisations[$immunisationsCount]['date'] = $immunisation['Approximate date'];
            $immunisationsCount++;
          }
        }
      }

      // Handle data for allergies
      if (!$field->isHeading() && $preHeader === 'ALLERGIES') {
        // If field has value
        if (!empty($value) && !empty($value->value)) {
          $options = $field->getOptions();
          $label = $options[0]->label;
          $currentlyAffected = false;
          $date = '';

          $childMaps = $field->getParentMaps();

          if ($label) {
            $allergies[$allergiesCount]['label'] = $label;
//            $allergies[$allergiesCount]['actionTaken'] = $actionTaken;
            foreach ($childMaps as $childMap) {
              $childField = $childMap->getChild();
              $childValue = $childField->getValue($zulu);

              if (is_array($childValue)) {
                $childValue = $childValue[0];
              }

              if (!empty($childValue) && !empty($childValue->value)) {
                // Dangerous when data changes
//                if (preg_match('/action taken/', $childField->alias)) {
//                  $actionTaken = $childValue->value;
//                }
                $allergies[$allergiesCount][$childField->label] = $childValue->value;
              }
            }
          }

          $allergiesCount++;
        }
      }

      // Handle data for operations
      if (!$field->isHeading() && $preHeader === 'OPERATIONS') {
        $operationData = json_decode(html_entity_decode($value->value), true);

        foreach ($operationData as $operation) {
          if (!$operation['Date'] && !$opration['Detail']) {
            continue;
          }
          // Dangerous when data changes
          $operations[$operationsCount]['date'] = $operation['Date'];
          $operations[$operationsCount]['details'] = $operation['Detail'];
          $operationsCount++;
        }
      }

      // Handle data for medications
      if (!$field->isHeading() && $preHeader === 'MEDICATIONS') {
        $medications['taking_medications'] = false;
        $medications['list'] = null;

        // If field has value
        if (!empty($value) && !empty($value->value)) {
          // If taking medications is yes
          if ($field->alias === 'taking medications' && strtolower($field->getOption($value->value)->label) === 'yes') {
            $childMaps = $field->getParentMaps();

            $medications['taking_medications'] = true;
            $medications['list'] = array();

            foreach ($childMaps as $map) {
              $childField = $map->getChild();
              if ($childField->alias === 'medications list') {
                $childValue = $childField->getValue($zulu);

                if (is_array($childValue)) {
                  $childValue = $childValue[0];
                }

                if (!empty($childValue) && !empty($childValue->value)) {
                  $medicationData = json_decode(html_entity_decode($childValue->value), true);

                  foreach ($medicationData as $medication) {
                    // Dangerous when data changes
                    foreach ($medication as $key => $value) {
                      if (!empty($value)) {
                        $medications['list'][$medicationsCount][$key] = $medication[$key];
                      }
                    }
                    $medicationsCount++;
                  }
                }
                break;
              }
            }
          }
        }
      }

      // Handle data for others
      if (!$field->isHeading() && $preHeader === 'OTHERS') {
        if ($field->alias && !empty($field->getValue($zulu)->value)) {
          if (count($field->getOptions()) > 0) {
            $others[str_replace(' ', '_', trim($field->alias))]['value'] = $field->getOption($field->getValue($zulu)->value)->label;

            $childMaps = Engine_Api::_()->fields()->getFieldsStructureFull($zulu, $field->field_id, $field->getValue($zulu)->value);

            if ($others[str_replace(' ', '_', trim($field->alias))]['value'] === 'Yes' && count($childMaps) > 0) {
              $childMap = reset($childMaps);
              if ($childMap) {
                $others[str_replace(' ', '_', trim($field->alias))]['reason'] = $childMap->getChild()->getValue($zulu)->value;
              }
            }
          } else {
            $others[str_replace(' ', '_', trim($field->alias))]['value'] = $field->getValue($zulu)->value;
          }
        }
      }
    }

    $this->view->bodyData = array(
        'zulu' => $zulu,
        'user' => $user,
        'userMetaData' => $userMetaData,
        'zuluMetaData' => $zuluMetaData,
        'dateFormat' => $dateFormat,
        // form part data for rendering in printing document
        'formPartData' => array(
            'childhoodDiseases' => $childhoodDiseases,
            'immunisations' => $immunisations,
            'allergies' => $allergies,
            'operations' => $operations,
            'medications' => $medications,
            'others' => $others,
        )
    );

    $this->_helper->layout->disableLayout();
    $this->renderScript('profile/print.tpl');
  }

}
