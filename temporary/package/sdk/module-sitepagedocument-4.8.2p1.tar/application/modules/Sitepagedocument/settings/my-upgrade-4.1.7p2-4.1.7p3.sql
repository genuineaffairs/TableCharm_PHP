DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.comment.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.like.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.featurelist.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.popular.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.rate.widgets' LIMIT 1;
DELETE FROM `engine4_core_settings` WHERE `engine4_core_settings`.`name` = 'sitepagedocument.recent.widgets' LIMIT 1;