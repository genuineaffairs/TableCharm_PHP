// $Id: README.txt, 2010-08-17 9:40:21Z SocialEngineAddOns Exp $

*******************************************************************************
Documents / Scribd iPaper Plugin for SocialEngine
  by SocialEngineAddOns - info (at) socialengineaddons (dot) com
*******************************************************************************

DESCRIPTION:
This folder contains the license for this plugin.

WARNING:
No changes should be made to the files in this folder.