<?php

class Grandopening_Model_Collection extends Core_Model_Item_Abstract
{
    protected $_searchTriggers = false;
}