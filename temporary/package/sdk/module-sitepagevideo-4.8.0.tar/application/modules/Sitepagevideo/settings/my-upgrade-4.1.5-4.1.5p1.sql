
UPDATE `engine4_seaocores` SET  `is_activate` =  '1' WHERE  `engine4_seaocores`.`module_name` = 'sitepagevideo' LIMIT 1 ;