<?php

/**
 * SocialEngine
 *
 * @category   Application_Extensions
 * @package    sitepageevent
 * @copyright  Copyright 2010-2011 BigStep Technologies Pvt. Ltd.
 * @license    http://www.socialengineaddons.com/license/
 * @version    $Id: Category.php 6590 2011-05-05 9:40:21Z SocialEngineAddOns $
 * @author     SocialEngineAddOns
 */
class Sitepageevent_Model_Category extends Core_Model_Item_Abstract
{
  protected $_searchTriggers = false;

  public function getUsedCount()
  {
    $eventTable = Engine_Api::_()->getItemTable('sitepageevent');
    return $eventTable->select()
        ->from($eventTable, new Zend_Db_Expr('COUNT(event_id)'))
        ->where('category_id = ?', $this->category_id)
        ->query()
        ->fetchColumn();
  }

  public function isOwner($owner)
  {
    return false;
  }

  public function getOwner($recurseType = null)
  {
    return $this;
  }
}
