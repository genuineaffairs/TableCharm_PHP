alter table engine4_communityad_adstatistics add index(viewer_id);
alter table engine4_communityad_adstatistics add index(userad_id);