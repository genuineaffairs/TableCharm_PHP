<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Grid
 *
 * @author abakivn
 */
class Zulu_Form_Element_Grid extends Zend_Form_Element_Xhtml {

  public $helper = 'formGrid';

  /**
   * Load default decorators
   *
   * @return void
   */
  public function loadDefaultDecorators() {
    if ($this->loadDefaultDecoratorsIsDisabled()) {
      return;
    }

    $decorators = $this->getDecorators();
    if (empty($decorators)) {
      $this->addDecorator('ViewHelper');
      Engine_Form::addDefaultDecorators($this);
      $this->addDecorator('HtmlTag3', array('tag' => 'div', 'class' => 'grid-form-element'));
    }
  }

  public function setValue($value) {
    if (is_array($value)) {
      $value = json_encode($value);
    }

    return parent::setValue($value);
  }

  public function getValue() {
    return parent::getValue();
  }
}
